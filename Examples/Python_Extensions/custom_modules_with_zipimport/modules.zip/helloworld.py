# demo module

hello_world = True
